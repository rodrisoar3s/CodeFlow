import subprocess
import shutil
from backend.db import get_conn


class Api:
    # ---------- Projetos ----------
    def get_projects(self):
        conn = get_conn()
        rows = conn.execute("SELECT * FROM projects").fetchall()
        conn.close()
        return [dict(r) for r in rows]

    def add_project(self, name, folder_path="", value_eur=0):
        conn = get_conn()
        conn.execute(
            "INSERT INTO projects (name, folder_path, value_eur) VALUES (?, ?, ?)",
            (name, folder_path, value_eur),
        )
        conn.commit()
        conn.close()
        return {"ok": True}

    # ---------- Abrir no VSCode ----------
    def open_in_vscode(self, folder_path):
        code_bin = shutil.which("code")
        if not code_bin:
            return {"ok": False, "error": "VSCode CLI 'code' não encontrado no PATH."}
        try:
            subprocess.Popen([code_bin, folder_path])
            return {"ok": True}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    # ---------- Ganhos do mês (para a Home) ----------
    def get_monthly_earnings(self):
        conn = get_conn()
        rows = conn.execute(
            "SELECT name, value_eur FROM projects"
        ).fetchall()
        conn.close()
        return [dict(r) for r in rows]
