import webview
from backend.api import Api
from backend.db import init_db

if __name__ == "__main__":
    init_db()
    api = Api()
    webview.create_window(
        title="Manager",
        url="ui/index.html",
        js_api=api,
        width=1280,
        height=800,
        min_size=(1000, 650),
        background_color="#1e1e1e",
    )
    webview.start(debug=True)
